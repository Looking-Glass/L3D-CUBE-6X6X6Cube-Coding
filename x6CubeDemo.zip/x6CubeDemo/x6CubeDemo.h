#define MICROPHONE 1
#define GAIN_CONTROL 3
//#define MAX_POINTS 20
#define SPEED 0.22


#define FIREWORKS 0
#define SQUARRAL 1
#define PLASMA 2
#define FFT_JOY 3
//#define SNAKE 4
#define MATRIX 4
#define RAINBOW3D 5
#define WALLBOUNCE 6
#define GOLDENRAIN 7
#define CUBESPANDER 8
#define ZEROGRAIN 9



#define DEMO_ROUTINES 10


void add(Point& a, Point& b);


/*******************************
 * fireworks variables *
 * ****************************/
 int centerX, centerY, centerZ;
int launchX, launchZ, fadeTimer;
int brightness=50;
float radius=0;
float speed;
bool showRocket;
bool exploded;
float xInc, yInc, zInc;
float rocketX, rocketY, rocketZ;
float launchTime;
int maxSize;
Color rocketColor, fireworkColor;



/*********************************
 * snake variables *
 * ******************************/

Point snake[10];


/*********************************
 * squarral variables *
 * ******************************/

#define TRAIL_LENGTH 25

int frame=0;
Color voxelColor;
Point position, increment, pixel;
Point trailPoints[TRAIL_LENGTH];
int posX, posY, posZ;
int incX, incY, incZ;
int squarral_zInc=1;
int bound=0;
int boundInc=1;
unsigned char axis=0;
bool rainbow=true;

//maxBrightness is the brightness limit for each pixel.  All color data will be scaled down 
//so that the largest value is maxBrightness
int maxBrightness=50;

/********************************
 *  * matrix variables *
 * *****************************/
 
#define VOX_POINTS 36

int voxelXw1[VOX_POINTS];
int voxelZw1[VOX_POINTS];
int voxelXw2[VOX_POINTS];
int voxelZw2[VOX_POINTS];
int voxelXw3[VOX_POINTS];
int voxelZw3[VOX_POINTS];
int voxelXw4[VOX_POINTS];
int voxelZw4[VOX_POINTS];
int voxDelay(150);
int wave01(7);
int wave02(10);
int wave03(15);
int wave04(19);
Color brightLine01 = Color(244, 241, 250);
Color brightLine02 = Color(98, 193, 97);
Color brightLine03 = Color(30, 131, 30);
Color brightLine04 = Color(5, 45, 6);
Color brightLine05 = Color(6, 25, 3);
Color brightLine06 = Color(8, 15, 3);
Color medLine01 = Color(20, 158, 18);
Color medLine02 = Color(41, 114, 41);
Color medLine03 = Color(5, 45, 6);
Color medLine04 = Color(6, 25, 3);
Color medLine05 = Color(8, 15, 3);
Color darkLine01 = Color(10, 70, 10);
Color darkLine02 = Color(5, 55, 4);
Color darkLine03 = Color(3, 30, 4);
Color darkLine04 = Color(2, 15, 1);
Color darkLine05 = Color(1, 8, 1);

/********************************
 * zplasma variables *
 * *****************************/
float phase = 0.0;
float phaseIncrement = 0.03; // Controls the speed of the moving points. Higher == faster
float colorStretch = 0.1; // Higher numbers will produce tighter color bands 
float plasmaBrightness = 0.2;
Color plasmaColor;

/*********************************
 * FFTJoy variables *
 * *******************************/
#define SAMPLES                 2048
#define M                       4   // If the M value changes, then the 'ARRAY_SIZE' constant also needs changing
#define ARRAY_SIZE              16  // to be changed to reflect the result of the formula: pow(2,M)
#define fftSampleNum 2
//======arduino only=======
//const int REA=pow(2,M);
//const int IMA=pow(2,M);
//=========================
float real[ARRAY_SIZE], imaginary[ARRAY_SIZE];  //real[REA];
//float imaginary[IMA];
float maxValue=0;
float sample;


/*********************************
 * WallBounce variables *
 * *******************************/
float xpos = 1, ypos = 1, zpos = 1; //sets position of x,y,z zxis
float xspeed = 0.1;
float yspeed = 0.1;
float zspeed = 0.1;

/*********************************
 * CubeSpander variables *
 * *******************************/

int side=0;
int inc=1;
int mode=0;
//int frame=0;
Color cubeCol;
void drawCube(Point topLeft, int side, Color col);
void drawLine(Point p1, Point p2, Color col);
void mixVoxel(Point currentPoint, Color col);
Color complement(Color original);

/*********************************
 * ZeroGRain variables *
 * *******************************/
int Gaxis = 1;    // Which axis are we crumbling through?  0=x, 1=y, 2=z.
int flips;
const int NUM_FLIPS = 5;
Color readVoxel;

/*********************************
 * GoldenRain variables *
 * *******************************/
   Color readColor;

  long runningAverage=0;
  static int previousRunningAverage=0;
  unsigned long readTime,colorTime=0;
  int mic=0;
  int readSampleNum=0;
  int amplitude=0;
  int maxAmplitude;

/**********************************
 * flip variables *
 * ********************************/
 //accelerometer pinout
#define X 10
#define Y 12
#define Z 11
#define AUTOCYCLE_TIME 22222
#define FACEPLANT 2350
#define UPSIDE_DOWN 1850
#define RIGHTSIDE_UP 1670   //this is different from 8x8x8 Cube, as the accelerometer is on the bottom side.
#define LEFT_SIDE 2300
#define RIGHT_SIDE 1700
#define FLIP_TIMEOUT 5000
#define FLIP_DEBOUNCE 250

long lastFaceplant=-1*FLIP_TIMEOUT;
bool upsideDown=false;
bool sideways=false;
bool autoCycle=true;    //start on autocycle by default
int upsideDownTime=-1*FLIP_TIMEOUT;
long lastAutoCycle=0;
int lastLeft=-1*FLIP_TIMEOUT;
int lastRight=-1*FLIP_TIMEOUT;
int accelerometer[3];
long lastChange=0;


int demo=FIREWORKS;

int frameCount=0;

/*******************************
 * fade variables *
 * ****************************/
bool fading=false;
int fadeValue=255;
int fadeSpeed=1;

Cube cube=Cube(6,50);
//Cube cube=Cube();

void initSquarral();
void squarral();
void Snake();
void romanCandle();
void mirror();
void matrixInit();
void matrix();
Color Wheel(byte WheelPos);
void WallBounce();
void Rainbow3D();

 void setVoxel( int x, int y, int z, bool clear );
 void resetZeroGRainCycle();
 bool shift();
 int draw();

 void drawCube(Point topLeft, int side, Color col);
 void drawLine(Point p1, Point p2, Color col);
 void mixVoxel(Point currentPoint, Color col);
 void cubeInc();
 void CubeSpander();

 void setVoxel( int x, int y, int z, Color col );
 Color getVoxel( int x, int y, int z);
 void ZeroGRainCycle();

 void GoldenRain();

void initFireworks();
void prepRocket();
void updateFireworks();
float distance(float x, float y, float z, float x1, float y1, float z1);
void add(Point& a, Point& b);

void fade();
void smoothFade();
void zPlasma();

void FFTJoy();
void FFTJoy2();
void FFTJoy3();
short FFT(short int dir,int m,float *x,float *y);

void checkFlipState();
void updateAccelerometer();
void setFadeSpeed();
void incrementDemo();
void decrementDemo();
